import { Hola } from './hola';

describe('Hola', () => {
  it('should create an instance', () => {
    expect(new Hola()).toBeTruthy();
  });
});

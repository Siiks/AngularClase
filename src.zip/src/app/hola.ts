export class Hola {
}

export class Hola {
}
